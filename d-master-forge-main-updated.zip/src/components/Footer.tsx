export const Footer = () => {
  return (
    <footer className="bg-muted/20 border-t border-border py-8 px-4">
      <div className="container mx-auto text-center">
        <p className="text-muted-foreground">
          © 2025 3D Master CZ. Všechna práva vyhrazena.
        </p>
      </div>
    </footer>
  );
};
