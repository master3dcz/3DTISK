import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Menu, X, ShoppingCart } from "lucide-react";

export const Navigation = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
      setIsOpen(false);
    }
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-lg border-b border-border">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="text-xl font-bold">
              <span className="bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
                3D Master CZ
              </span>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-6">
            <Link 
              to="/"
              className={`transition-[var(--transition-smooth)] ${
                isActive("/") ? "text-primary" : "text-foreground hover:text-primary"
              }`}
            >
              Domů
            </Link>
            <Link 
              to="/tisk-na-miru"
              className={`transition-[var(--transition-smooth)] ${
                isActive("/tisk-na-miru") ? "text-primary" : "text-foreground hover:text-primary"
              }`}
            >
              Tisk na míru
            </Link>
            <Link 
              to="/produkty"
              className={`transition-[var(--transition-smooth)] ${
                isActive("/produkty") ? "text-primary" : "text-foreground hover:text-primary"
              }`}
            >
              Produkty
            </Link>
            <Link 
              to="/o-nas"
              className={`transition-[var(--transition-smooth)] ${
                isActive("/o-nas") ? "text-primary" : "text-foreground hover:text-primary"
              }`}
            >
              O nás
            </Link>
            {(
              <button 
                onClick={() => scrollToSection("contact")}
                className="text-foreground hover:text-primary transition-[var(--transition-smooth)]"
              >
                Kontakt
              </button>
            )}
            <Button variant="outline" size="sm" className="border-primary hover:bg-primary/10">
              <ShoppingCart className="w-4 h-4 mr-2" />
              Košík (0)
            </Button>
          </div>

          {/* Mobile menu button */}
          <button
            onClick={() => setIsOpen(!isOpen)}
            className="md:hidden text-foreground"
          >
            {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isOpen && (
          <div className="md:hidden py-4 space-y-4">
            <Link 
              to="/"
              onClick={() => setIsOpen(false)}
              className={`block w-full text-left transition-[var(--transition-smooth)] ${
                isActive("/") ? "text-primary" : "text-foreground hover:text-primary"
              }`}
            >
              Domů
            </Link>
            <Link 
              to="/tisk-na-miru"
              onClick={() => setIsOpen(false)}
              className={`block w-full text-left transition-[var(--transition-smooth)] ${
                isActive("/tisk-na-miru") ? "text-primary" : "text-foreground hover:text-primary"
              }`}
            >
              Tisk na míru
            </Link>
            <Link 
              to="/produkty"
              onClick={() => setIsOpen(false)}
              className={`block w-full text-left transition-[var(--transition-smooth)] ${
                isActive("/produkty") ? "text-primary" : "text-foreground hover:text-primary"
              }`}
            >
              Produkty
            </Link>
            <Link 
              to="/o-nas"
              onClick={() => setIsOpen(false)}
              className={`block w-full text-left transition-[var(--transition-smooth)] ${
                isActive("/o-nas") ? "text-primary" : "text-foreground hover:text-primary"
              }`}
            >
              O nás
            </Link>
            {(
              <button 
                onClick={() => scrollToSection("contact")}
                className="block w-full text-left text-foreground hover:text-primary transition-[var(--transition-smooth)]"
              >
                Kontakt
              </button>
            )}
            <Button variant="outline" size="sm" className="w-full border-primary hover:bg-primary/10">
              <ShoppingCart className="w-4 h-4 mr-2" />
              Košík (0)
            </Button>
          </div>
        )}
      </div>
    </nav>
  );
};
