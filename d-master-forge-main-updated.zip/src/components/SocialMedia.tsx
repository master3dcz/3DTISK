import { Facebook, Youtube, Instagram } from "lucide-react";
import { Button } from "@/components/ui/button";

const socialLinks = [
  {
    name: "Facebook",
    icon: Facebook,
    url: "https://www.facebook.com/profile.php?id=61582377293780&locale=cs_CZ",
    color: "hover:text-[#1877F2]"
  },
  {
    name: "YouTube",
    icon: Youtube,
    url: "https://www.youtube.com/@3DMasterCZ",
    color: "hover:text-[#FF0000]"
  },
  {
    name: "Instagram",
    icon: Instagram,
    url: "https://www.instagram.com/3dmastercz/?utm_source=ig_web_button_share_sheet",
    color: "hover:text-[#E4405F]"
  }
];

export const SocialMedia = () => {
  return (
    <section className="py-12 px-4 bg-muted/20">
      <div className="container mx-auto text-center">
        <h3 className="text-2xl font-bold mb-6">Sledujte nás</h3>
        <div className="flex justify-center gap-4 flex-wrap">
          {socialLinks.map((social) => (
            <Button
              key={social.name}
              variant="outline"
              size="lg"
              asChild
              className="border-primary hover:bg-primary/10"
            >
              <a 
                href={social.url} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-2"
              >
                <social.icon className={`w-5 h-5 ${social.color}`} />
                {social.name}
              </a>
            </Button>
          ))}
          <Button
            variant="outline"
            size="lg"
            asChild
            className="border-primary hover:bg-primary/10"
          >
            <a 
              href="https://www.tiktok.com/@3dmastercz?is_from_webapp=1&sender_device=pc" 
              target="_blank" 
              rel="noopener noreferrer"
              className="flex items-center gap-2"
            >
              <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
              </svg>
              TikTok
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
};
