
export const Products = () => {
  return (
    <section className="py-40 px-4">
      <div className="container mx-auto text-center">
        <h1 className="text-6xl font-extrabold">Brzy</h1>
        <p className="mt-6 text-muted-foreground">Naše nové produkty se připravují. Sledujte nás na sociálních sítích.</p>
      </div>
    </section>
  );
};

export default Products;
