import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Upload, Send } from "lucide-react";

const formSchema = z.object({
  name: z.string().trim().min(1, "Jméno je povinné").max(100, "Jméno je příliš dlouhé"),
  email: z.string().trim().email("Neplatná emailová adresa").max(255, "Email je příliš dlouhý"),
  phone: z.string().trim().min(9, "Telefon musí mít alespoň 9 znaků").max(20, "Telefon je příliš dlouhý"),
  message: z.string().trim().min(10, "Zpráva musí mít alespoň 10 znaků").max(1000, "Zpráva je příliš dlouhá"),
});

type FormData = z.infer<typeof formSchema>;

export const CustomPrintingForm = () => {
  const [file, setFile] = useState<File | null>(null);
  const { toast } = useToast();
  
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    resolver: zodResolver(formSchema),
  });

  const onSubmit = async (data: FormData) => {
    try {
      // Simulace odeslání - v budoucnu nahradit edge function
      console.log("Form data:", data);
      console.log("File:", file);
      
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      toast({
        title: "Poptávka odeslána!",
        description: "Děkujeme za váš zájem. Ozveme se vám co nejdříve.",
      });
      
      reset();
      setFile(null);
    } catch (error) {
      toast({
        title: "Chyba",
        description: "Nepodařilo se odeslat formulář. Zkuste to prosím znovu.",
        variant: "destructive",
      });
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      const allowedTypes = ['.stl', '.obj', '.3mf', '.step', '.stp'];
      const fileExtension = selectedFile.name.substring(selectedFile.name.lastIndexOf('.')).toLowerCase();
      
      if (!allowedTypes.includes(fileExtension)) {
        toast({
          title: "Neplatný formát",
          description: "Podporované formáty: STL, OBJ, 3MF",
          variant: "destructive",
        });
        return;
      }
      
      if (selectedFile.size > 50 * 1024 * 1024) {
        toast({
          title: "Soubor je příliš velký",
          description: "Maximální velikost souboru je 50 MB",
          variant: "destructive",
        });
        return;
      }
      
      setFile(selectedFile);
    }
  };

  return (
    <Card className="bg-card border-border max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="text-2xl">Poptávkový formulář</CardTitle>
        <CardDescription>
          Vyplňte formulář a my se vám ozveme s cenovou nabídkou
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="name">Jméno a příjmení *</Label>
            <Input
              id="name"
              placeholder="Jan Novák"
              {...register("name")}
              className="border-border"
            />
            {errors.name && (
              <p className="text-sm text-destructive">{errors.name.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="email">Email *</Label>
            <Input
              id="email"
              type="email"
              placeholder="jan.novak@email.cz"
              {...register("email")}
              className="border-border"
            />
            {errors.email && (
              <p className="text-sm text-destructive">{errors.email.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="phone">Telefon *</Label>
            <Input
              id="phone"
              type="tel"
              placeholder="+420 123 456 789"
              {...register("phone")}
              className="border-border"
            />
            {errors.phone && (
              <p className="text-sm text-destructive">{errors.phone.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Popis projektu *</Label>
            <Textarea
              id="message"
              placeholder="Popište, co potřebujete vytisknout, materiál, barvu, rozměry..."
              rows={4}
              {...register("message")}
              className="border-border"
            />
            {errors.message && (
              <p className="text-sm text-destructive">{errors.message.message}</p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="file">3D model (nepovinné)</Label>
            <div className="flex items-center gap-4">
              <Input
                id="file"
                type="file"
                accept=".stl,.obj,.3mf,.step,.stp"
                onChange={handleFileChange}
                className="border-border"
              />
              {file && (
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Upload className="w-4 h-4" />
                  <span className="truncate max-w-[200px]">{file.name}</span>
                </div>
              )}
            </div>
            <p className="text-xs text-muted-foreground">
              Podporované formáty: STL, OBJ, 3MF (max 50 MB)
            </p>
          </div>

          <Button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-primary hover:bg-primary-glow text-primary-foreground"
          >
            <Send className="w-4 h-4 mr-2" />
            {isSubmitting ? "Odesílám..." : "Odeslat poptávku"}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};
