import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import heroImage from "@/assets/hero-3d-printing.jpg";

export const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div 
        className="absolute inset-0 z-0"
        style={{
          backgroundImage: `url(${heroImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          filter: 'brightness(0.4)'
        }}
      />
      
      <div className="container mx-auto px-4 z-10 text-center">
        <h1 className="text-5xl md:text-7xl font-bold mb-6 animate-fade-in">
          <span className="bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
            3D Master CZ
          </span>
        </h1>
        <p className="text-xl md:text-2xl mb-8 text-foreground max-w-2xl mx-auto">
          Profesionální 3D tisk na míru
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Link to="/tisk-na-miru">
            <Button 
              size="lg" 
              className="bg-primary hover:bg-primary-glow text-primary-foreground shadow-[var(--shadow-glow)] transition-[var(--transition-smooth)] hover:shadow-[var(--shadow-glow-lg)]"
            >
              Tisk na míru
            </Button>
          </Link>
          <Link to="/produkty">
            <Button 
              size="lg" 
              variant="outline"
              className="border-primary text-primary hover:bg-primary/10"
            >
              Naše produkty
            </Button>
          </Link>
        </div>
      </div>
    </section>
  );
};
