import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Upload, MessageSquare, Printer } from "lucide-react";
import { CustomPrintingForm } from "./CustomPrintingForm";

export const CustomPrinting = () => {
  return (
    <section id="custom-printing" className="py-20 px-4 bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold text-center mb-4">
          <span className="bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
            Tisk na míru
          </span>
        </h2>
        <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
          Nabízíme dva způsoby, jak můžete získat váš vlastní 3D tisk
        </p>
        
        <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
          <Card className="bg-card border-border hover:border-primary transition-[var(--transition-smooth)] hover:shadow-[var(--shadow-glow)]">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Upload className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>Pošlete nám 3D návrh</CardTitle>
              <CardDescription>
                Máte již hotový 3D model? Stačí nám ho poslat a my se postaráme o zbytek.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• Podporované formáty: STL, OBJ, 3MF</li>
                <li>• Maximální velikost: 250 x 210 x 220 mm</li>
                <li>• Cenová nabídka do 24 hodin</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="bg-card border-border hover:border-primary transition-[var(--transition-smooth)] hover:shadow-[var(--shadow-glow)]">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <MessageSquare className="w-6 h-6 text-primary" />
              </div>
              <CardTitle>Návrh na domluvě</CardTitle>
              <CardDescription>
                Nemáte 3D model? Rádi vám pomůžeme s návrhem a realizací vašeho projektu.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-muted-foreground">
                <li>• Konzultace zdarma</li>
                <li>• Návrh na míru</li>
                <li>• Revize a úpravy designu</li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <div className="mt-16 max-w-3xl mx-auto">
          <Card className="bg-card border-border">
            <CardHeader>
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4 mx-auto">
                <Printer className="w-6 h-6 text-primary" />
              </div>
              <CardTitle className="text-center">Jak to probíhá?</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid md:grid-cols-4 gap-6 text-center">
                <div>
                  <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center mx-auto mb-3 font-bold">
                    1
                  </div>
                  <h4 className="font-semibold mb-2">Kontakt</h4>
                  <p className="text-sm text-muted-foreground">Napište nám nebo zavolejte</p>
                </div>
                <div>
                  <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center mx-auto mb-3 font-bold">
                    2
                  </div>
                  <h4 className="font-semibold mb-2">Konzultace</h4>
                  <p className="text-sm text-muted-foreground">Probereme váš požadavek</p>
                </div>
                <div>
                  <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center mx-auto mb-3 font-bold">
                    3
                  </div>
                  <h4 className="font-semibold mb-2">Tisk</h4>
                  <p className="text-sm text-muted-foreground">Vytiskneme váš produkt</p>
                </div>
                <div>
                  <div className="w-8 h-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center mx-auto mb-3 font-bold">
                    4
                  </div>
                  <h4 className="font-semibold mb-2">Dodání</h4>
                  <p className="text-sm text-muted-foreground">Doručíme přímo k vám</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="mt-16">
          <CustomPrintingForm />
        </div>
      </div>
    </section>
  );
};
