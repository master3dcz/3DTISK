import { Card, CardContent } from "@/components/ui/card";
import { Mail, Phone } from "lucide-react";

export const Contact = () => {
  return (
    <section id="contact" className="py-20 px-4 bg-gradient-to-b from-background to-muted/20">
      <div className="container mx-auto max-w-4xl">
        <h2 className="text-4xl font-bold text-center mb-4">
          <span className="bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
            Kontakt
          </span>
        </h2>
        <p className="text-center text-muted-foreground mb-12">
          Neváhejte nás kontaktovat, rádi vám pomůžeme
        </p>

        <div className="grid md:grid-cols-2 gap-6">
          <Card className="bg-card border-border hover:border-primary transition-[var(--transition-smooth)] hover:shadow-[var(--shadow-glow)]">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-2">Email</h3>
                  <a 
                    href="mailto:master3dcz@gmail.com" 
                    className="text-primary hover:text-primary-glow transition-[var(--transition-smooth)]"
                  >
                    master3dcz@gmail.com
                  </a>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border hover:border-primary transition-[var(--transition-smooth)] hover:shadow-[var(--shadow-glow)]">
            <CardContent className="pt-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="font-bold mb-2">Telefon</h3>
                  <div className="space-y-1">
                    <div>
                      <p className="text-sm text-muted-foreground">Petr Pražák</p>
                      <a 
                        href="tel:+420605009411" 
                        className="text-primary hover:text-primary-glow transition-[var(--transition-smooth)]"
                      >
                        +420 605 009 411
                      </a>
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground">Petr Melichar</p>
                      <a 
                        href="tel:+420736172600" 
                        className="text-primary hover:text-primary-glow transition-[var(--transition-smooth)]"
                      >
                        +420 736 172 600
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};
