
import { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';

type CartItem = { id: number, name: string, price: number, qty: number, weight?: number, size?: number };

const STORAGE_KEY = '3dm_cart_demo';

const carriers = ['Zasilkovna','PPL','Ceskapost','DPD'];

function calcShipping(carrier:string, pickup:boolean, weight:number, size:number) {
  // weight in kg, size in cm (largest dimension)
  if (carrier === 'Zasilkovna') {
    if (pickup) return 89;
    // on address: standard up to 5kg -> 89, nadrozmerna up to15kg ->149
    if (weight <=5) return 129; // on address price specified earlier: 129
    return 149;
  }
  if (carrier === 'PPL') {
    if (pickup) {
      if (weight<=2) return 65;
      if (weight<=5) return 75;
      if (weight<=10) return 155;
      if (weight<=20) return 335;
      return 450;
    } else {
      if (weight<=2) return 180;
      if (weight<=5) return 212;
      if (weight<=10) return 265;
      if (weight<=20) return 331;
      return 437;
    }
  }
  if (carrier === 'Ceskapost') {
    // size S(35cm) 129 M(50cm)159 L(100cm)209
    if (size<=35) return 129;
    if (size<=50) return 159;
    return 209;
  }
  if (carrier === 'DPD') {
    if (pickup) return 0;
    // address: size to 3kg ->68, to10kg->75
    if (size <= 3) return 68;
    return 75;
  }
  return 0;
}

function generateVS(){ return String(Date.now()).slice(-6); }

const Cart = () => {
  const [items,setItems] = useState<CartItem[]>([]);
  const [carrier,setCarrier] = useState('Zasilkovna');
  const [pickup,setPickup] = useState(true);
  const [payment,setPayment] = useState('bank');
  const [vs,setVs] = useState('');
  const [qrUrl,setQrUrl] = useState('');

  useEffect(()=>{
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) setItems(JSON.parse(raw));
  },[]);

  useEffect(()=>{ localStorage.setItem(STORAGE_KEY, JSON.stringify(items)); },[items]);

  const subtotal = items.reduce((s,i)=>s + i.price*i.qty,0);
  // approximate weight and size totals
  const totalWeight = items.reduce((s,i)=>s + (i.weight||0)*i.qty,0);
  const maxSize = items.reduce((s,i)=>Math.max(s, i.size||0),0);

  const shipping = calcShipping(carrier, pickup, totalWeight, maxSize);
  const dobirka = payment === 'dobirka' ? (carrier==='Zasilkovna'?26: carrier==='PPL' ? (subtotal<=1000?46:59) : carrier==='Ceskapost'?60:0) : 0;
  const total = subtotal + shipping + dobirka;

  const makeQr = ()=>{
    const IBAN = 'CZ6508000000000000000000';
    const myvs = generateVS();
    setVs(myvs);
    // SPD format
    const spd = `SPD*1.0*ACC:${IBAN}*AM:${total.toFixed(2)}*CC:CZK*X-VS:${myvs}*MSG:Objednavka_${myvs}`;
    const qr = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' + encodeURIComponent(spd);
    setQrUrl(qr);
  };

  const clearCart = ()=>{ setItems([]); localStorage.removeItem(STORAGE_KEY); setQrUrl(''); setVs(''); };

  return (
    <section className="py-20 px-4">
      <div className="container mx-auto max-w-4xl">
        <h2 className="text-3xl font-bold mb-6">Košík</h2>
        {items.length === 0 ? (
          <div className="text-center text-muted-foreground">Košík je prázdný.</div>
        ) : (
          <div>
            <div className="space-y-4 mb-6">
              {items.map(it=> (
                <div key={it.id} className="p-4 border rounded flex justify-between items-center">
                  <div>
                    <div className="font-semibold">{it.name}</div>
                    <div className="text-sm text-muted-foreground">ks: {it.qty} • {it.weight || 0} kg</div>
                  </div>
                  <div className="text-right">
                    <div className="font-semibold">{it.price * it.qty} Kč</div>
                    <div className="text-sm mt-2">
                      <Button onClick={()=>{ setItems(items.filter(x=>x.id!==it.id)); }} variant="ghost">Smazat</Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <h3 className="text-xl font-semibold mb-2">Doprava a platba</h3>
            <div className="mb-4">
              <label className="block mb-2">Dopravce</label>
              <select value={carrier} onChange={(e)=>setCarrier(e.target.value)} className="p-2 rounded bg-muted/10">
                <option value="Zasilkovna">Zásilkovna</option>
                <option value="PPL">PPL</option>
                <option value="Ceskapost">Česká pošta</option>
                <option value="DPD">DPD</option>
              </select>
            </div>
            <div className="mb-4">
              <label className="block mb-2">Vybrat typ doručení</label>
              <select value={pickup ? 'pickup' : 'address'} onChange={(e)=>setPickup(e.target.value==='pickup')} className="p-2 rounded bg-muted/10">
                <option value="pickup">Výdejní místo</option>
                <option value="address">Na adresu</option>
              </select>
            </div>
            <div className="mb-4">
              <label className="block mb-2">Způsob platby</label>
              <select value={payment} onChange={(e)=>setPayment(e.target.value)} className="p-2 rounded bg-muted/10">
                <option value="bank">Bankovní převod</option>
                <option value="qr">QR platba</option>
                <option value="dobirka">Dobírka</option>
              </select>
            </div>

            <div className="p-4 border rounded mb-4">
              <div>Mezisoučet: {subtotal} Kč</div>
              <div>Doprava: {shipping} Kč</div>
              <div>Dobírka / poplatek: {dobirka} Kč</div>
              <div className="font-bold mt-2">Celkem: {total} Kč</div>
            </div>

            {payment === 'qr' && (
              <div className="mb-4">
                <Button onClick={makeQr} className="mb-4">Generovat QR (pevná částka)</Button>
                {qrUrl && (
                  <div>
                    <div>Variabilní symbol: <strong>{vs}</strong></div>
                    <img src={qrUrl} alt="QR" />
                    <p className="text-sm text-muted-foreground mt-2">QR obsahuje pevně částku a VS podle košíku. Systém objednávku neoznačí jako zaplacenou, pokud banka pošle jinou částku.</p>
                  </div>
                )}
              </div>
            )}

            {payment !== 'qr' && (
              <div className="mb-4">
                <Button onClick={()=>{ alert('Uložit objednávku a čekat na platbu (demo)'); clearCart(); }}>Dokončit objednávku</Button>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};

export default Cart;
