import { Card, CardContent } from "@/components/ui/card";
import { Users, Target, Zap } from "lucide-react";

export const About = () => {
  return (
    <section id="about" className="py-20 px-4">
      <div className="container mx-auto max-w-6xl">
        <h2 className="text-4xl font-bold text-center mb-4">
          <span className="bg-gradient-to-r from-primary to-primary-glow bg-clip-text text-transparent">
            O nás
          </span>
        </h2>
        <p className="text-center text-muted-foreground mb-12 max-w-2xl mx-auto">
          Tým začínajících 3D vývojářů a nadšenců pro 3D technologie.