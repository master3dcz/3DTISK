import { Navigation } from "@/components/Navigation";
import { CustomPrinting } from "@/components/CustomPrinting";
import { Footer } from "@/components/Footer";

const CustomPrintingPage = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="pt-16">
        <CustomPrinting />
      </div>
      <Footer />
    </div>
  );
};

export default CustomPrintingPage;
