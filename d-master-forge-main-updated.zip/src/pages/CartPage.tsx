
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import Cart from "@/components/Cart";

const CartPage = () => {
  return (
    <div className="min-h-screen">
      <Navigation />
      <div className="pt-16">
        <Cart />
      </div>
      <Footer />
    </div>
  );
};

export default CartPage;
